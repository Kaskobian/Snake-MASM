// main.c

#include <stdio.h>

extern void _asmMain( );
extern void _printSingle( float d, int precision );

int main( )
{
	asmMain( );
	return 0;
}